import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DelaersPanelComponent } from './delaers-panel.component';

describe('DelaersPanelComponent', () => {
  let component: DelaersPanelComponent;
  let fixture: ComponentFixture<DelaersPanelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DelaersPanelComponent]
    });
    fixture = TestBed.createComponent(DelaersPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
