import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { dealerRegister } from '../Model/dealerRegister';
import { DealersService } from '../Services/dealers.service';
import { UserServiceService } from '../Services/user-service.service';
import { ROLES } from '../common';

@Component({
  selector: 'app-delaers-panel',
  templateUrl: './delaers-panel.component.html',
  styleUrls: ['./delaers-panel.component.css']
})
export class DelaersPanelComponent implements OnInit {
  @ViewChild('form') form!: NgForm;
  showForm: boolean = true;
  showTable: boolean = true;
  dealersList: any[] = [];
  addDealer = new dealerRegister;
  formattedDate: string;
  emailExist: boolean = false;
  constructor(private dealerService: DealersService, private router: Router, private userService: UserServiceService) {
    const currentDate = new Date();
    const day = currentDate.getDate().toString().padStart(2, '0');
    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Months are 0-based, so add 1
    const year = currentDate.getFullYear();

    // Extract time components
    const hours = currentDate.getHours().toString().padStart(2, '0');
    const minutes = currentDate.getMinutes().toString().padStart(2, '0');
    const seconds = currentDate.getSeconds().toString().padStart(2, '0');

    // Format the date and time as "DD.MM.YYYY HH:MM:SS"
    this.formattedDate = `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
  }
  ngOnInit(): void {
    this.showForm = false;
    this.dealerService.getDealerList().subscribe(response => {
      this.dealersList = response
    });
  }
  showForms() {
    this.showForm = true;
    this.showTable = false;
  }
  showTables() {
    this.showTable = true;
    this.showForm = false;
    this.dealerService.getDealerList().subscribe(response => {
      this.dealersList = response

      console.log(this.dealersList);
    });
  }
  OnSubmit() {
    this.addDealer.FullName = this.form.value.name;
    this.addDealer.Email = this.form.value.email;
    this.addDealer.MobileNumber = this.form.value.mobileNo;
    this.addDealer.Role = ROLES.Dealer;
    this.addDealer.CreatedDate = this.formattedDate;
    this.addDealer.Password = this.form.value.password;
    this.addDealer.Address = this.form.value.Address;
    if (this.form.valid) {
      this.emailExist = this.checkIfEmailExists(this.addDealer.Email)

      if (this.emailExist) {
        alert('Email Already Registered');
        window.location.reload();
      }
      else {
        this.dealerService.addDealer(this.addDealer).subscribe(response => {
          this.userService.registerUser(this.addDealer).subscribe(response2 => {
            alert('Added');
            window.location.reload();
          });

        });
      }


      this.showForm = false;
    }



  }

  editDealer(item: any) {
    item.isEditing = true;
  }
  checkIfEmailExists(email: string): boolean {
    // Use Array.some() to check if the email exists in the array
    return this.dealersList.some((user => user.Email === email));
  }
  saveItem(item: any) {
    item.isEditing = false;
    this.dealerService.updateValue(item.id, item).subscribe(response => {
      console.log(response);
    });
  }
  cancelEdit(item: any) {
    item.isEditing = false;
  }
  deleteDealer(item: any) {
    this.dealerService.deleteItem(item.id).subscribe(response => {
      this.dealerService.getDealerList().subscribe(response => {
        this.dealersList = response
        console.log(response);
        alert("dealer deleted successfully");
      });

    });
  }

}
