import { Component } from '@angular/core';
import { userRegister } from '../Model/Userregister';
import { AuthServiceService } from '../Services/auth-service.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent {
  showform: boolean = false;
  showBtn: boolean = false;
  IsAdmin: boolean = false;
  IsDealer: boolean = false;
  
  UserData: any
  constructor(private authService: AuthServiceService){}
  ngOnInit(): void {
    
    this.UserData = localStorage.getItem('role');
    
    console.log(this.UserData.Role);
    if(this.UserData == 'Admin'){
      this.IsAdmin = true;
    }
    else if(this.UserData == 'Dealer'){
      this.IsDealer = true;
    }
    else{
      this.IsAdmin = false;
      this.IsDealer = false;
    }

  }
  Onclick(){
    this.showBtn = true;
  }
  showForm(){
    this.showform = false;
  }
  Dashboard(){
    window.location.reload();
  }

}
