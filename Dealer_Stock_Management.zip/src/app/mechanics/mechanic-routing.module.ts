import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MechanicPanelComponent } from './mechanic-list/mechanic-list.component';

const routes: Routes = [
  {
    path: '',
    component: MechanicPanelComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MechanicRoutingModule { }
