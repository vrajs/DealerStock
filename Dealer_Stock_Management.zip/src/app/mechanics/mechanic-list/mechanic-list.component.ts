import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { mechanicRegister } from '../../Model/mechanicRegister';
import { DealersService } from '../../Services/dealers.service';
import { MechanicService } from '../../Services/mechanic.service';
import { ROLES } from 'src/app/common';

@Component({
  selector: 'app-mechanic-panel',
  templateUrl: './mechanic-list.component.html',
  styleUrls: ['./mechanic-list.component.css']
})
export class MechanicPanelComponent implements OnInit {
  @ViewChild('form') form!: NgForm;
  showForm: boolean = true;
  showTable: boolean = true;
  mechanics: any[] = [];
  addMechanic = new mechanicRegister;
  formattedDate: string;
  dealers: any;
  selectedDealerId: number = -1;
  today: string = new Date().toISOString().split('T')[0];
  emailExist: boolean = false;

  constructor(private mechanicsData: MechanicService, private router: Router, private dealerService: DealersService) {
    const currentDate = new Date();
    const day = currentDate.getDate().toString().padStart(2, '0');
    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Months are 0-based, so add 1
    const year = currentDate.getFullYear();
    const hours = currentDate.getHours().toString().padStart(2, '0');
    const minutes = currentDate.getMinutes().toString().padStart(2, '0');
    const seconds = currentDate.getSeconds().toString().padStart(2, '0');

    // Format the date and time as "DD.MM.YYYY HH:MM:SS"
    this.formattedDate = `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
    this.dealerService.getDealerList().subscribe(response => {
      this.dealers = response;
    });
    this.mechanicsData.getMechanicList().subscribe(response => {
      this.mechanics = response

      console.log(this.mechanics);
    });
  }
  ngOnInit(): void {
    this.showForm = false;
  }
  OnSubmit() {
    this.addMechanic.FullName = this.form.value.name;
    this.addMechanic.BirthDate = this.form.value.birthDate;
    this.addMechanic.DealerId = this.selectedDealerId;
    this.addMechanic.Email = this.form.value.email;
    this.addMechanic.MobileNumber = this.form.value.mobileNo;
    this.addMechanic.Role = ROLES.Mechanic;
    this.addMechanic.CreatedDate = this.formattedDate;
    console.log(this.addMechanic);
    console.log(this.form.valid);
    if (this.form.valid) {

      this.emailExist = this.checkIfEmailExists(this.addMechanic.Email);
      if (this.emailExist) {
        alert('User Already Register');
        this.router.navigateByUrl('/mechanic');
        window.location.reload();
      }
      else {
        this.mechanicsData.addMechanic(this.addMechanic).subscribe(response => {

        });
        alert('Added');
        window.location.reload();
        this.showForm = false;
      }

    }
    else {
      alert('Invalid Form');
    }


  }
  checkIfEmailExists(email: string): boolean {
    // Use Array.some() to check if the email exists in the array
    return this.mechanics.some((user => user.Email === email));
  }

  showForms() {
    this.showForm = true;
    this.showTable = false;
  }
  showTables() {
    this.showTable = true;
    this.showForm = false;
    this.mechanicsData.getMechanicList().subscribe(response => {
      this.mechanics = response

      console.log(this.mechanics);
    });
  }
  editMechanic(mechanic: any) {
    mechanic.isEditing = true;
  }
  saveItem(mechanic: any) {
    mechanic.isEditing = false;
    this.mechanicsData.updateValue(mechanic.id, mechanic).subscribe(response => {
      console.log(response);
    });
  }
  deleteMechanic(mechanic: any) {
    this.mechanicsData.deleteItem(mechanic.id).subscribe(response => {
      this.mechanicsData.getMechanicList().subscribe(response => {
        this.mechanics = response
        alert("Mechanic deleted successfully");
        console.log(this.mechanics);
      });
      console.log(response);
    })
  }
  cancelEdit(mechanic: any) {
    mechanic.isEditing = false;

  }
}
