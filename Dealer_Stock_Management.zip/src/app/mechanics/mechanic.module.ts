import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MechanicPanelComponent } from './mechanic-list/mechanic-list.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../sharemodule/shared.module';
import { RouteRoutingModule } from '../route/route-routing.module';
import { MechanicRoutingModule } from './mechanic-routing.module';

@NgModule({
  declarations: [MechanicPanelComponent],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    MechanicRoutingModule
  ]
})
export class MechanicModule { }
