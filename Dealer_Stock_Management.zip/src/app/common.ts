export const ROLES = {
    Mechanic: 'Mechanic',
    Admin: 'Admin',
    Dealer: "Dealer"
};