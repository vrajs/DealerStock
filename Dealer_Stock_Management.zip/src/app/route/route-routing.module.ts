import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AllPartsPanelComponent } from '../all-parts-panel/all-parts-panel.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { DelaersPanelComponent } from '../delaers-panel/delaers-panel.component';
import { LoginComponent } from '../login/login.component';
import { MechanicPanelComponent } from '../mechanics/mechanic-list/mechanic-list.component';
import { RegisterComponent } from '../register/register.component';
import { AuthGuard } from '../shared/auth.guard';

const routes: Routes = [{path: 'Dashboard', component: DashboardComponent, canActivate: [AuthGuard], data:{expectedRole: ['Admin','Dealer']}},
// {path: 'mechanic-panel',component: MechanicPanelComponent, canActivate: [AuthGuard], data: { expectedRole: ['Admin' ]}},
{
  path: 'mechanic',
  loadChildren: () => import('./../../app/mechanics/mechanic.module').then(m => m.MechanicModule),canActivate: [AuthGuard], data:{expectedRole: [  'Admin','Dealer']}
},
{path: 'dealer-panel',component: DelaersPanelComponent, canActivate: [AuthGuard], data: { expectedRole: [ 'Admin'] }},
{path: 'login',component: LoginComponent},
{path: 'register', component: RegisterComponent},
{path: 'parts-panel', component: AllPartsPanelComponent, canActivate: [AuthGuard], data:{expectedRole: [  'Admin','Dealer']}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RouteRoutingModule { }
