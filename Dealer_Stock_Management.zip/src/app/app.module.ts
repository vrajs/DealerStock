import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { RouteModule } from './route/route.module';
import { HttpClientModule } from '@angular/common/http';
import { UserServiceService } from './Services/user-service.service';
import { DashboardComponent } from './dashboard/dashboard.component';

import { DelaersPanelComponent } from './delaers-panel/delaers-panel.component';
import { AllPartsPanelComponent } from './all-parts-panel/all-parts-panel.component';

import { SharedModule } from './sharemodule/shared.module';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
 
    DelaersPanelComponent,
    AllPartsPanelComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouteModule,
    FormsModule,
    HttpClientModule,
    SharedModule
  ],
  providers: [UserServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
