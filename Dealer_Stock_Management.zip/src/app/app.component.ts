import { Component,DoCheck,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceService } from './Services/auth-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,DoCheck  {
  title = 'Dealer_Stock_Management';
  url!: string;
  public segments: string[] = []; 
  hideComponenet: boolean = false;
  hideLogOut: boolean = false;
  constructor(private router: Router, private authService: AuthServiceService) {}
  
  ngOnInit(): void {
    
    this.url = window.location.href;
    this.segments = this.url.split("/");
    this.url = this.segments[this.segments.length -1];
    console.log(this.url);
    if(this.url === ''){
    this.hideComponenet = true;
    }
    if(this.url ==='Dashboard'){
      this.hideLogOut = false;
    }
  }
  ngDoCheck(): void {
    this.url = window.location.href;
    this.segments = this.url.split("/");
    this.url = this.segments[this.segments.length -1];
    if(this.url ==='Dashboard')
    {
      this.hideLogOut = false;
    }
  }
  logOut(){
    this.authService.logout();
    this.router.navigateByUrl('login');
  }
    redirect(){
      this.hideComponenet = false;
    }
    Dashboard(){
      window.location.reload();
    }
}


