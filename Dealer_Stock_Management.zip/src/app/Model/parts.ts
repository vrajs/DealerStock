export class parts {
    id!: number;
    partName!: string;
    description!: string;
    stockQuantity!: Number;
    createdDate!: string;
    dealerId!: number;
}