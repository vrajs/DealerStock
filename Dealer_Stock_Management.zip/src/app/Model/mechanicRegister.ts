export class mechanicRegister{
    Id!: number
    FullName!: string;
    Email!: string;
    MobileNumber!: string;
    DealerId!: Number;
    Role!: string;
    BirthDate!: Date;
	CreatedDate!: string;
}