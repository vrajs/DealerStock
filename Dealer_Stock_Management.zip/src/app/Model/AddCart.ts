export class addCarts {
    id!: number;
    UserId!: number;
    Name!: string;
    Quantity!: number;
    AssignedMechanic!: string;
}