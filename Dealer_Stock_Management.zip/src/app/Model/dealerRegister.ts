export class dealerRegister{
    int!: number;
    FullName!: string;
    Email!: string;
    Address!: string;
    MobileNumber!: number
    Password!: string;
    Role!: string
    CreatedDate!: string 
}