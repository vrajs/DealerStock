export class userRegister {
    id!: number;
    FullName!: string;
    Email!: string;
    Password!: string;
    Role!: string
}