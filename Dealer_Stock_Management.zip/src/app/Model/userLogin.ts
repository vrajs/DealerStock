export class userLogin{
   Email!: string;
   Password!: string;
   LoggedInDate!: Date;
   
}