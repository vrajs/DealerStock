import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateFn, Router, RouterStateSnapshot } from '@angular/router';
import { AuthServiceService } from '../Services/auth-service.service';


@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(
    private authService: AuthServiceService,
    private router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const expectedRole = route.data['expectedRole']; // Define expected roles in your route configuration
    if (this.authService.isAuthenticated() && this.authService.hasRole(expectedRole)) {
      return true; // Allow access if authenticated and has the expected role
    } else {
      // Not authenticated or does not have the expected role
      this.router.navigate(['/login']); // Redirect to the login page
      return false;
    }
  }
}
