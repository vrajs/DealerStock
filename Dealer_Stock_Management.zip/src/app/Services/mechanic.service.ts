import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { mechanicRegister } from '../Model/mechanicRegister';

@Injectable({
  providedIn: 'root'
})
export class MechanicService {

  private apiurl ='http://localhost:3000/';
  constructor(private http:HttpClient) { }

  getMechanicList(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiurl}Mechanic`);
  }
  addMechanic(data: any): Observable<any>{
   return this.http.post(`${this.apiurl}Mechanic`, data)
  }
  updateValue(id: number, newValue: any): Observable<any> {
    const url = `http://localhost:3000/Mechanic/${id}`;
    return this.http.put(url, newValue);
  }
  deleteItem(id: number): Observable<any> {
    const url = `http://localhost:3000/Mechanic/${id}`;
    return this.http.delete(url);
  }
  
}
