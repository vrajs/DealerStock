import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { userLogin } from '../Model/userLogin';
import { userRegister } from '../Model/Userregister';
import { JsonPipe } from '@angular/common';
@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  private apiurl ='http://localhost:3000/';

  constructor( private http: HttpClient) {
    
    
   }
  
  registerUser(userRegister:any): Observable<any> {
    
    localStorage.setItem('currentUser', JSON.stringify(userRegister));
  return this.http.post(`${this.apiurl}userRegister`, userRegister);
  }


  login(data: any): Observable<any> {
    // Pause execution for debugging
    ;
    
    return this.getUsers().pipe(
      map((users: any[]) => {
        // Pause execution for debugging
        ;
        
        const user = users.find((u) => u.Email === data.Email && u.Password === data.Password);
        
        if (user) {
          // Serialize the user data and store it in localStorage
          const userData = JSON.stringify(user);
          localStorage.setItem('User', userData);
          localStorage.setItem('isLoggedIn', 'true');
          
          // Return the authenticated user
          return user;
        } else {
          // Throw an error if login credentials are invalid
          throw new Error('Invalid credentials');
        }
      })
    );
  }
  
  UserLogin(data: any): Observable<any>{
    return this.http.post(`${this.apiurl}UserLogin`, data);
  }
  getUsers(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:3000/userRegister');
  }
}
