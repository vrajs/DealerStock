import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { addCarts } from '../Model/AddCart';

@Injectable({
  providedIn: 'root'
})
export class AddCartService {

  private apiurl ='http://localhost:3000/';
  constructor(private http: HttpClient) { }
  addCarts(data: addCarts): Observable<any>{
    return this.http.post(`${this.apiurl}PartsAdded`, data)
   }
   getAddCartList(userId: any): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiurl}PartsAdded?UserId=${userId}`);
  }
  deleteCarts(id: number): Observable<any> {
    const url = `http://localhost:3000/PartsAdded/${id}`;
    return this.http.delete(url);
  }
}
