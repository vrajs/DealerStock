import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { addCarts } from '../Model/AddCart';
import { parts } from '../Model/parts';

@Injectable({
  providedIn: 'root'
})
export class PartsService {
  private apiurl ='http://localhost:3000/';
  constructor(private http:HttpClient) { }

  getPartsListList(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiurl}PartsDetails`);
  }
  addParts(data: parts): Observable<any>{
    return this.http.post(`${this.apiurl}PartsDetails`, data)
   }
   getByDealerId(dealerId: string): Observable<any> {
    const url = `${this.apiurl}PartsDetails?dealerId=${dealerId}`;
    return this.http.get<any[]>(url);
  }
  updateValue(id: number, newValue: any): Observable<any> {
    const url = `http://localhost:3000/PartsDetails/${id}`;
    return this.http.put(url, newValue);
  }
  deleteItem(id: number): Observable<any> {
    const url = `http://localhost:3000/PartsDetails/${id}`;
    return this.http.delete(url);
  }

}
