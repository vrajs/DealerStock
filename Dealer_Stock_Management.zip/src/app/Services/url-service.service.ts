import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UrlServiceService {

  href: string = '';


  constructor(private router: Router, private activatedRoute: ActivatedRoute) { }
    getCurrentPath(){
      
        this.href = this.router.url;
        this.href.split('/');
        console.log(this.router.url);
    return this.href;
    }
  }
