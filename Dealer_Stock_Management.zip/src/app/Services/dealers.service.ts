import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { dealerRegister } from '../Model/dealerRegister';

@Injectable({
  providedIn: 'root'
})
export class DealersService {

  private apiurl ='http://localhost:3000/';
  constructor(private http:HttpClient) { }

  getDealerList(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiurl}DealerData`);
  }
  addDealer(data: dealerRegister): Observable<any>{
    return this.http.post(`${this.apiurl}DealerData`, data)
   }
   updateValue(id: number, newValue: any): Observable<any> {
    const url = `http://localhost:3000/DealerData/${id}`;
    return this.http.put(url, newValue);
  }
  deleteItem(id: number): Observable<any> {
    const url = `http://localhost:3000/DealerData/${id}`;
    return this.http.delete(url);
  }
}
