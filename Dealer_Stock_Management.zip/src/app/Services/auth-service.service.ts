import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {
    private userRole: any;
    UserData: any;
    constructor(private route: Router){

    }
  setUserRole(role: string): void{
    localStorage.setItem('role', role);
  }
  getUserRole():any {
     
    return localStorage.getItem('role');
  }
  private isLoggedIn = false;

  login_Verified() {
    
    this.isLoggedIn = true;
    this.UserData = JSON.parse(localStorage.getItem('User')!);
    localStorage.setItem('isLoggedIn', 'true')
  }

  register_Verified() {
    this.isLoggedIn = true;
  }

  logout() {
    this.isLoggedIn = false;
    localStorage.removeItem('currentUser');
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('User');
    localStorage.removeItem('role');
  }

  isAuthenticated(): boolean {
    return this.isLoggedIn || localStorage.getItem('isLoggedIn') === 'true';
    
  }
  hasRole(expectedRole: string[]): boolean {
    // Check if the user has the expected role
    if (this.isAuthenticated()) {
      
      for (const item of expectedRole) {
        if (item === this.getUserRole()) {
          return true;
        }
      }
      alert('You Are Not Authorized');
      this.route.navigateByUrl('/login'); 
   
      
      
    }
    return false;
  }
}

