import { Component, OnInit, ViewChild } from '@angular/core';
import {FormsModule, NgForm } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { concat } from 'rxjs';
import { userRegister } from '../Model/Userregister';
import { AuthServiceService } from '../Services/auth-service.service';
import { UserServiceService } from '../Services/user-service.service';
import { ROLES } from '../common';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  @ViewChild('form') form!: NgForm;
  userData = new userRegister;
  allUser: any[] = [];
  emailExist: boolean = false;
 
  constructor(private userService: UserServiceService, private router: Router, private auth: AuthServiceService){}
  ngOnInit(): void {
    
  }
  OnSubmit(){
this.userData.FullName = this.form.value.first_name + this.form.value.last_name;;
this.userData.Email = this.form.value.email;
this.userData.Role = ROLES.Admin;
this.userData.Password = this.form.value.password;
if(this.form.valid)
{
  this.userService.getUsers().subscribe(response =>{
    this.allUser = response;
     this.emailExist = this.checkIfEmailExists(this.userData.Email);
  });
if(this.emailExist){
  alert('User Already Register');
  window.location.reload();
}
else{


  this.userService.registerUser(this.userData).subscribe(response =>{
    ;
    if(response != null){
      this.auth.register_Verified();
      this.auth.setUserRole(this.userData.Role);
      alert('User Registered')
      this.router.navigateByUrl('/Dashboard')
    }
    console.log(response);
  });
}
}
console.log(this.userData);
  }
  checkIfEmailExists(email: string): boolean {
    // Use Array.some() to check if the email exists in the array
    return this.allUser.some((user => user.Email === email));
  }
}
