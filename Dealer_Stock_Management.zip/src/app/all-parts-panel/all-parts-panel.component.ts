import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ResolveEnd, Router } from '@angular/router';
import { addCarts } from '../Model/AddCart';
import { parts } from '../Model/parts';
import { AddCartService } from '../Services/add-cart.service';
import { DealersService } from '../Services/dealers.service';
import { MechanicService } from '../Services/mechanic.service';
import { PartsService } from '../Services/parts.service';

@Component({
  selector: 'app-all-parts-panel',
  templateUrl: './all-parts-panel.component.html',
  styleUrls: ['./all-parts-panel.component.css']
})
export class AllPartsPanelComponent implements OnInit {
  @ViewChild('form') form!: NgForm;
  showForm: boolean = true;
  showTable: boolean = true;
  PartsList: any;
  addParts = new parts;
  addCarts = new addCarts;
  selectedDealerId: number = -1;
  dealers: any;
  mechanics: any;
  selectedMechanicId: string = ""
  formattedDate: string;
  isCartOpen: boolean = false;
  cartTable: boolean = false;
  cartItems: any = "";
  totalQuantityParts: any
  selectedName: any;
  selectedParts: any
  currentUser: any
  isDisable: boolean = false;
  selectedFilter: any;
  selectedQuantity: number = 0;
  stockQuantityError: boolean = false;
  constructor(private cdr: ChangeDetectorRef, private cartService: AddCartService, private partsService: PartsService, private dealerService: DealersService, private mechanicService: MechanicService, private router: Router) {
    const currentDate = new Date();
    const day = currentDate.getDate().toString().padStart(2, '0');
    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Months are 0-based, so add 1
    const year = currentDate.getFullYear();
    const hours = currentDate.getHours().toString().padStart(2, '0');
    const minutes = currentDate.getMinutes().toString().padStart(2, '0');
    const seconds = currentDate.getSeconds().toString().padStart(2, '0');

    // Format the date and time as "DD.MM.YYYY HH:MM:SS"
    this.formattedDate = `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
    this.dealerService.getDealerList().subscribe(response => {
      this.dealers = response;
    })
    this.mechanicService.getMechanicList().subscribe(response => {
      this.mechanics = response;
    })
  }
  ngOnInit(): void {
    const userString = localStorage.getItem('User');
    if (userString !== null) {
      this.currentUser = JSON.parse(userString);
    } else {
      // Handle the case where 'User' key does not exist in localStorage
    }
    this.showForm = false;

  }
  OnSubmit() {
    this.addParts.createdDate = this.formattedDate;
    this.addParts.partName = this.form.value.name;
    this.addParts.dealerId = this.selectedDealerId;
    this.addParts.stockQuantity = this.form.value.stockQuantity;
    this.addParts.description = this.form.value.description;
    if (this.form.valid) {
      this.partsService.addParts(this.addParts).subscribe(response => {
        console.log(response);
        this.showForm = false;
      });
    }

  }
  showForms() {
    this.showForm = true;
    this.showTable = false;
    this.cartTable = false;
  }

  showTables() {
    this.showTable = true;
    this.showForm = false;
    
    // this.currentUser = JSON.parse(localStorage.getItem('User'));
    this.cartService.getAddCartList(this.currentUser.id).subscribe(response => {
      this.cartItems = response;
      console.log(this.cartItems);
    });

    this.partsService.getPartsListList().subscribe(response => {
      this.PartsList = response;

      console.log(this.PartsList);
    });

    if (this.cartItems != "") {
      this.cartTable = true;
    }


  }
  toggleCart() {
    this.isCartOpen = !this.isCartOpen;
  }
  editParts(item: any) {
    item.isEditing = true;
  }
  saveItem(item: any) {
    item.isEditing = false;
    this.partsService.updateValue(item.id, item).subscribe(response => {
      console.log(response);
    });
  }
  cancelEdit(item: any) {
    item.isEditing = false;
  }
  deleteParts(item: any) {
    this.partsService.deleteItem(item.id).subscribe(response => {
      console.log(response);
    });
    ;
    this.router.navigate([this.router.url]);
    this.cdr.detectChanges();
  }

  addButton() {

    this.isCartOpen = false;
    this.cartTable = true;
    this.selectedQuantity;
    this.selectedParts.stockQuantity = this.selectedParts.stockQuantity - this.selectedQuantity;
    console.log('updated', this.selectedParts);
    this.selectedMechanicId;
    this.selectedQuantity;
    this.addCarts.Name = this.selectedName;
    this.addCarts.Quantity = this.selectedQuantity;
    this.addCarts.AssignedMechanic = this.selectedMechanicId;

    this.addCarts.UserId = this.currentUser?.id;
    console.log(this.addCarts);

    this.partsService.updateValue(this.selectedParts.id, this.selectedParts).subscribe(response => {
      console.log(response);
    });

    this.cartService.addCarts(this.addCarts).subscribe(response => {
      console.log(response);
    })

    this.cartService.getAddCartList(this.currentUser.id).subscribe(response => {
      this.cartItems = response;
    })

  }
  AddToCart(parts: any) {
    this.isCartOpen = true;
    this.selectedName = parts.partName;
    this.totalQuantityParts = parts.stockQuantity;
    this.selectedParts = parts;


  }
  deleteCarts(item: any) {
    this.cartService.deleteCarts(item.id).subscribe(response => {
      console.log(response);
    });
    this.cartService.getAddCartList(this.currentUser.id).subscribe(response => {
      this.cartItems = response;
    });


    this.cdr.detectChanges();
  }
  closeCart() {
    this.isCartOpen = false;
  }
  onFilterChange() {
    this.partsService.getByDealerId(this.selectedDealerId.toString()).subscribe(response => {
      console.log(response);
      ;
      this.PartsList = response;

    });
  }
  verifyQuantity(): void {
    if (this.selectedParts.stockQuantity < this.selectedQuantity) {
      console.error('Stock quantity is insufficient');
      this.stockQuantityError = true;
      this.isDisable = true;
    }
    else {
      this.stockQuantityError = false;
      this.isDisable = false;

    }
  }
}
