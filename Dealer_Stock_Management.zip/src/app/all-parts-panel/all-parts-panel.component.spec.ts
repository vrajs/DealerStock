  import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllPartsPanelComponent } from './all-parts-panel.component';

describe('AllPartsPanelComponent', () => {
  let component: AllPartsPanelComponent;
  let fixture: ComponentFixture<AllPartsPanelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AllPartsPanelComponent]
    });
    fixture = TestBed.createComponent(AllPartsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
