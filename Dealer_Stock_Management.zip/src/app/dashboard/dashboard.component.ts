import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  showform: boolean = false;
  showBtn: boolean = false;
  constructor(){}
  ngOnInit(): void {
    
  }
  showForm(){
    this.showform = true;
  }
}
