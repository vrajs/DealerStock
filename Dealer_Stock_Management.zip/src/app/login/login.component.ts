import { Component,OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { userLogin } from '../Model/userLogin';
import { AuthServiceService } from '../Services/auth-service.service';
import { UserServiceService } from '../Services/user-service.service';
import { AuthGuard } from '../shared/auth.guard';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @ViewChild('form') form!: NgForm 
  userLogin = new userLogin;
  
  constructor(private userService: UserServiceService, private auth: AuthServiceService, private router: Router){}
  ngOnInit(): void {
    
  }
  Onclick(){
    
this.userLogin.Email = this.form.value.username;
this.userLogin.Password = this.form.value.pass;
console.log(this.userLogin);
if(this.form.valid)
{
  ;
  this.userService.login(this.userLogin).subscribe(response=>{
   
      ;
      console.log(response);
      localStorage.setItem('user', response);
      this.auth.login_Verified();
      this.auth.setUserRole(response.Role);
      this.router.navigateByUrl('/Dashboard')
    
  
      console.log(this.form.valid);
    });    
}

  }
}
